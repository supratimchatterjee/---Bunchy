/* global window */
/* global document */
/* global jQuery */

/* Place all your JavaScript modifications below */

(function ($) {

    "use strict";

    $(document).ready(function () {

        // YOUR "DOCUMENT READY" CODE GOES HERE ...

    });

    $(window).load(function () {

        // YOUR "WINDOW READY" CODE GOES HERE ...

    });

})(jQuery);
