<?php
/**
 * Snax Post Row Featured Image
 *
 * @package snax
 * @subpackage Theme
 */

$snax_featured_image = snax_get_format_featured_image( 'text' );
?>

<div class="snax-edit-post-row-media">
	<?php
	$snax_class = array(
		'snax-tab-content',
		'snax-tab-content-current',
		'snax-tab-content-image',
		'snax-tab-content-' . ( $snax_featured_image ? 'hidden' : 'visible' ),
	);
	?>
	<div class="<?php echo implode( ' ', array_map( 'sanitize_html_class', $snax_class ) ); ?>">
		<?php snax_get_template_part( 'posts/form-edit/new', 'image' ); ?>
	</div>

	<div id="snax-featured-image">
		<?php
		if ( $snax_featured_image ) {
			global $post;
			$post = $snax_featured_image;
			setup_postdata( $post );

			snax_get_template_part( 'featured-image' );

			wp_reset_postdata();
		}
		?>
	</div>
</div>
