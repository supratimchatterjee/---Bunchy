<?php
/**
 * Custom ad location after the second snax item
 *
 * @package snax
 * @subpackage Theme
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}
?>
<div class="snax-ad-location snax-ad-location-after-item-3">
	<?php quads_ad( array( 'location' => 'snax_after_item_3' ) ); ?>
</div>
